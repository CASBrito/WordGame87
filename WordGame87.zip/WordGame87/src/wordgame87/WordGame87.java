/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordgame87;

import java.util.*;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author gfgma
 */
public class WordGame87 {

    /**
     * @param args the command line arguments
     */
    static char[] charFile;
    static String opcao;
    static String correctWord;// = "ponte";
    static int tries;
    static Scanner sc = new Scanner(System.in);
    static String guessWord;
    static boolean check;
    static List<String> dictionaryList = new ArrayList<String>(); //{"ponte", "table", "carro", "bimbo", "happy", "mount", 
                                 //"cinco", "tries", "class", "jogar"};
    static String[] dictionary;
    static char[] charCorrect;
    static String correctLetter;
    static String correctLetterWrongPosition;
    static String incorrectLetter;
    
    public static void main(String[] args) {
        // TODO code application logic here
        readFile();
        
        //Teste para saber se as palavras do ficheiro teem 5 letras4
        /*for (int i = 0; i < dictionary.length ; i++){
            System.out.println(dictionary[i]);
        }*/
        
        menu();
        
    }
    
    private static void menu(){
        System.out.println("MAIN MENU");
        System.out.println("1: Jogar");
        System.out.println("2: Estatísticas");
        System.out.println("3: Regras");
        System.out.println("4: Sair");
        System.out.print("Selecione uma opção: ");
        opcao = sc.nextLine();
        
        switch(opcao){
            case "1":{
                jogar();
            }
            case "2":{
            
            }
            case "3":{
                
            }
            case "4":{
                System.exit(0);
            }
            default:
                System.out.println("Opção não válida.");
        }
    }
    
    private static void jogar(){
       

        
        correctLetter = "As letras no sítio certo são: ";
        correctLetterWrongPosition = "As letras certas no sítio errado são: ";
        incorrectLetter = "As letras erradas são: ";
        
        boolean checkI = false;
        
        correctWord = getRandom(dictionary);
        
        //Teste para saber qual é a palavra
        //A ser removido depois
        System.out.println("A palavra correta é: " + correctWord);
        
        tries = 6;
        
        //int count = 0;
        
        while(tries > 0){
            System.out.println("Tentativas restantes: " + tries);
            System.out.print("Adivinha a palavra: ");
            guessWord = sc.nextLine();
            check = true;
            
            char[] chars;
            chars = guessWord.toCharArray();
            charCorrect = correctWord.toCharArray();
            

            
            
            if(chars.length == 5){
                for(char c=0; c < chars.length; c++){
                    if(!Character.isLetter(chars[c])){
                        check = false;
                        break;
                    }   
                }
                    if(guessWord.equals(correctWord)){
                        System.out.println("Parabéns, Adivinhaste a palavra!");
                        break;
                    }else if(!check){                        
                        System.out.println("Palavra com caracteres inválidos");
                        tries--;
                    }else{
                            /*for(int z = 0; z < chars.length; z++){
                                final StringBuilder sb = new StringBuilder(chars[z]);
                                sb.append(chars[z]);
                                sb.toString();
                                final StringBuilder sbGW = new StringBuilder(charCorrect[z]);
                                sbGW.append(charCorrect[z]);
                                sbGW.toString();
                                if(guessWord.contains(sbGW) && sb.compareTo(sbGW) == 0) {
                                    correctLetter = correctLetter + chars[z] + " ";
                                }
                                        System.out.println(chars[z] + " " + charCorrect[z] + " " + sb + " " + sbGW + " " + guessWord.contains(sbGW) + " " + sb.equals(sbGW));
                                }
                                        /*correctLetterWrongPosition = correctLetterWrongPosition + chars[j] + " ";
                                        System.out.println(chars[z] + " " + charCorrect[j]);
                                        break;

                                    }
                                }else{
                                    checkI = true;

                            }
                            }
                                if(checkI){
                                    incorrectLetter = incorrectLetter + chars[j] + " ";
                                }
                            
                            //count++;
                        }*/
                        System.out.println("Palavra errada.");
                        System.out.println(correctLetter);
                        System.out.println(correctLetterWrongPosition);
                        System.out.println(incorrectLetter);
                        tries--;
                    }
                    
            }else{
                System.out.println("Tamanho da palavra inválido.");
                tries--;
            }
        }

            
        if(tries == 0){
            System.out.println("0 tentativas restantes. Perdeste. Voltando ao menu principal...");
        }
            
        menu();
        
    }
    
    public static String getRandom(String[] dictionaryRnd) {
        int rnd = new Random().nextInt(dictionaryRnd.length);
        return dictionaryRnd[rnd];
    }
    
    private static void readFile() {
        
        
                
        String fileName = "/Users/gfgma/Documents/popular.txt";
        
        try {
            Path path = Paths.get(fileName);
            try (Scanner myReader = new Scanner(path)) {
                while (myReader.hasNextLine()) {
                    check = true;
                    String data = myReader.nextLine();
                    charFile = data.toCharArray();
                    if(charFile.length == 5){
                            dictionaryList.add(data);
                    }
                }
                
            } catch (Exception e){
                System.out.println(e);
            }
        } catch (Exception  e) {
            System.out.println(e);
        }
        
        dictionary = new String[dictionaryList.size()];
        dictionaryList.toArray(dictionary);
    }
}
